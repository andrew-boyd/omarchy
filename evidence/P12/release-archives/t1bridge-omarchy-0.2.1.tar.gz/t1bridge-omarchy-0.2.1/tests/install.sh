#!/bin/bash

set -euo pipefail
ROOT=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)
test_root=$(mktemp -d)
trap 'rm -rf -- "$test_root"' EXIT

make -s -C "$ROOT" install DESTDIR="$test_root"
expected=(
  usr/lib/t1bridge-omarchy/auto-brightness
  usr/lib/systemd/user/t1bridge-auto-brightness.service
  usr/lib/t1bridge-omarchy/desktop-provider
  usr/lib/t1bridge-omarchy/session-start
  usr/lib/systemd/user/t1-touchbar.service.d/40-t1bridge-omarchy.conf
  usr/share/licenses/t1bridge-omarchy/LICENSE
  usr/share/doc/t1bridge-omarchy/README.md
  usr/share/doc/t1bridge-omarchy/docs/integration.md
)
diff -u <(printf '%s\n' "${expected[@]}" | LC_ALL=C sort) \
  <(cd "$test_root" && find . -type f -printf '%P\n' | LC_ALL=C sort)
[[ -x $test_root/usr/lib/t1bridge-omarchy/desktop-provider ]]
[[ -x $test_root/usr/lib/t1bridge-omarchy/session-start ]]
[[ $(stat -c %a "$test_root/usr/lib/systemd/user/t1-touchbar.service.d/40-t1bridge-omarchy.conf") == 644 ]]
cmp "$ROOT/lib/desktop-provider" "$test_root/usr/lib/t1bridge-omarchy/desktop-provider"
cmp "$ROOT/lib/session-start" "$test_root/usr/lib/t1bridge-omarchy/session-start"
printf 'ok - installation owns exactly eight declared files\n'

sentinels=(etc/pam.d/sudo etc/pam.d/polkit-1 etc/pam.d/omarchy-lock-fingerprint
  usr/bin/omarchy-shell usr/lib/systemd/user/t1-touchbar.service.d/20-omarchy-desktop-provider.conf
  home/synthetic/.config/t1bridge/renderer var/lib/t1bridge/machine-data/calibration.fscl)
for path in "${sentinels[@]}"; do
  install -Dm600 /dev/null "$test_root/$path"
  printf 'synthetic existing file: %s\n' "$path" >"$test_root/$path"
done
before=$(cd "$test_root" && sha256sum "${sentinels[@]}")
make -s -C "$ROOT" install DESTDIR="$test_root"
after=$(cd "$test_root" && sha256sum "${sentinels[@]}")
[[ $before == "$after" ]]
printf 'ok - repeated install preserves PAM, Omarchy, renderer and machine-data files\n'
