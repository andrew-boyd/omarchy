#!/bin/bash
set -euo pipefail
ROOT=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)
source "$ROOT/lib/auto-brightness"
[[ $(brightness_step 600 600 100 100 1000) == 600 ]]
[[ $(brightness_step 600 600 50 100 1000) == 580 ]]
[[ $(brightness_step 600 600 200 100 1000) == 620 ]]
[[ $(brightness_step 600 600 101 100 1000) == 600 ]]
[[ $(brightness_step 100 600 0 1000 1000) == 100 ]]
[[ $(brightness_step 1000 600 100000 1 1000) == 1000 ]]
[[ $(brightness_step 400 400 50 50 1000) == 400 ]]
printf 'ok - light response, smoothing, hysteresis, bounds and manual anchor\n'
root=$(mktemp -d)
trap 'rm -rf "$root"' EXIT
mkdir -p "$root/bus/iio/devices" "$root/usb/sensor/iio:device7"
printf '05ac\n' > "$root/usb/idVendor"
printf '8600\n' > "$root/usb/idProduct"
touch "$root/usb/sensor/iio:device7/in_illuminance_raw"
ln -s "$root/usb/sensor/iio:device7" "$root/bus/iio/devices/iio:device7"
[[ $(t1_light_sensor "$root") == "$root/usb/sensor/iio:device7" ]]
printf 'ffff\n' > "$root/usb/idProduct"
! t1_light_sensor "$root"
printf '8600\n' > "$root/usb/idProduct"
mkdir "$root/bus/iio/devices/iio:device8"
touch "$root/bus/iio/devices/iio:device8/in_illuminance_input"
! t1_light_sensor "$root"
rm "$root/bus/iio/devices/iio:device8/in_illuminance_input"
for attribute in in_illuminance0_input in_illuminance_clear_raw in_intensity_clear_raw; do
  touch "$root/bus/iio/devices/iio:device8/$attribute"
  ! t1_light_sensor "$root"
  rm "$root/bus/iio/devices/iio:device8/$attribute"
done
mkdir "$root/bus/iio/devices/iio:device8/scan_elements"
touch "$root/bus/iio/devices/iio:device8/scan_elements/in_intensity_both_en"
! t1_light_sensor "$root"
rm "$root/bus/iio/devices/iio:device8/scan_elements/in_intensity_both_en"
for extra in class/hwmon/hwmon8/light bus/platform/devices/synthetic/light class/misc/fastrpc-adsp class/misc/fastrpc-sdsp1; do
  mkdir -p "$(dirname "$root/$extra")"
  touch "$root/$extra"
  ! t1_light_sensor "$root"
  rm "$root/$extra"
  [[ $(t1_light_sensor "$root") == "$root/usb/sensor/iio:device7" ]]
done
printf 'ok - T1 ancestry required; ambiguous and foreign sensors rejected\n'
loginctl() { printf '%s\n' "$SESSION_FIXTURE"; }
SESSION_FIXTURE=$'Active=yes\nLockedHint=no\nType=wayland'
session_usable
SESSION_FIXTURE=$'Active=yes\nLockedHint=yes\nType=wayland'
! session_usable
SESSION_FIXTURE=$'Active=no\nLockedHint=no\nType=wayland'
! session_usable
printf 'ok - lock and inactive session suppress brightness policy\n'

# Exercise the actual consumer with a synthetic monitor and clock. No desktop,
# sensor daemon, login session, or hardware command is invoked by this harness.
mkdir "$root/bin"
cat > "$root/bin/stdbuf" <<'MONITOR'
#!/bin/bash
exec /usr/bin/sleep 30
MONITOR
chmod +x "$root/bin/stdbuf"
run_scenario() (
  scenario=$1
  export PATH="$root/bin:$PATH"
  cycle=0 delivered=false burst=0 SECONDS=0
  value_file="$root/$scenario.value"
  writes_file="$root/$scenario.writes"
  printf '600\n' > "$value_file"
  : > "$writes_file"
  reports=('+++ iio-sensor-proxy appeared' '    Light changed: 100 (lux)' '    Light changed: 200 (lux)')
  expected=600 expected_writes=0
  case $scenario in
    ordinary) expected=620; expected_writes=1 ;;
    vanished) reports[2]='--- iio-sensor-proxy vanished, waiting for it to appear' ;;
    proxy_replaced) reports[2]='+++ iio-sensor-proxy appeared' ;;
    sensor_appeared) reports[2]='+++ Light sensor appeared' ;;
    sensor_disappeared) reports[2]='--- Light sensor disappeared' ;;
    no_sensor) reports[2]='=== No ambient light sensor' ;;
    non_lux) reports[2]='    Light changed: 20 (vendor)' ;;
    ambiguity|sensor_replaced) ;;
    queued_loss) reports+=('--- Light sensor disappeared') ;;
    locked) reports+=('' '    Light changed: 400 (lux)') ;;
    manual) expected=1000 ;;
    cached_only) reports=('+++ iio-sensor-proxy appeared' '=== Has ambient light sensor (value: 800, unit: lux)') ;;
    *) exit 1 ;;
  esac
  panel_backlight() { printf 'synthetic-panel\n'; }
  t1_light_sensor() {
    if (( cycle >= 2 )); then
      [[ $scenario != ambiguity ]] || return 1
      if [[ $scenario == sensor_replaced ]]; then printf '/synthetic/replaced\n'; return; fi
    fi
    printf '/synthetic/original\n'
  }
  session_usable() { [[ $scenario != locked || $cycle != 2 ]]; }
  brightnessctl() {
    case ${*: -1} in
      max) printf '1000\n' ;;
      get) cat "$value_file" ;;
      *)
        [[ ${*: -2:1} == set ]] || return 1
        printf '%s\n' "${*: -1}" > "$value_file"
        printf 'write\n' >> "$writes_file"
        ;;
    esac
  }
  read() {
    (( cycle < ${#reports[@]} )) || return 1
    if [[ $scenario == queued_loss && $cycle == 2 ]] && (( burst < 32 )); then
      ((burst += 1))
      line='    Light changed: 200 (lux)'
      return 0
    fi
    $delivered && return 142
    delivered=true
    [[ -n ${reports[cycle]} ]] || return 142
    line=${reports[cycle]}
  }
  sleep() {
    ((cycle += 1, SECONDS += 31))
    delivered=false
    if [[ $scenario == manual && $cycle == 2 ]]; then printf '1000\n' > "$value_file"; fi
  }
  if run_brightness > "$root/$scenario.output"; then
    echo "consumer failed to stop for $scenario" >&2
    exit 1
  fi
  [[ $(<"$value_file") == "$expected" ]]
  [[ $(wc -l < "$writes_file") == "$expected_writes" ]]
)
for scenario in ordinary vanished proxy_replaced sensor_appeared sensor_disappeared no_sensor non_lux ambiguity sensor_replaced queued_loss locked manual cached_only; do
  run_scenario "$scenario"
done
printf 'ok - consumer loop discards stale streams and preserves manual/lock preferences with synthetic commands\n'
