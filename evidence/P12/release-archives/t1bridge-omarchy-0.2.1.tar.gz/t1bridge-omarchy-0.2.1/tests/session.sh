#!/bin/bash

set -euo pipefail
ROOT=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)
test_root=$(mktemp -d)
trap 'rm -rf -- "$test_root"' EXIT
mkdir "$test_root/bin"
cat >"$test_root/bin/systemctl" <<'STUB'
#!/bin/bash
printf '%s\n' "$*" >>"$CALLS"
[[ $1 == --user ]] || exit 1
case $2 in
  cat) [[ ${UNIT_PRESENT:-yes} == yes ]] ;;
  import-environment) [[ ${IMPORT_FAIL:-no} == no ]] ;;
  daemon-reload|try-restart) exit 0 ;;
  *) exit 1 ;;
esac
STUB
chmod +x "$test_root/bin/systemctl"
calls="$test_root/calls"
run() { env -i PATH="$test_root/bin:/usr/bin" CALLS="$calls" "$@" "$ROOT/lib/session-start"; }

run
[[ ! -e $calls ]]
run OMARCHY_PATH=/synthetic/omarchy
[[ ! -e $calls ]]
run WAYLAND_DISPLAY=wayland-synthetic
[[ ! -e $calls ]]
printf 'ok - session helper does nothing outside a graphical Omarchy session\n'

run OMARCHY_PATH=/synthetic/omarchy WAYLAND_DISPLAY=wayland-synthetic UNIT_PRESENT=no
[[ $(<"$calls") == '--user cat t1-touchbar.service' ]]
printf 'ok - missing renderer unit is a no-op\n'

: >"$calls"
run OMARCHY_PATH=/synthetic/omarchy WAYLAND_DISPLAY=wayland-synthetic \
  DISPLAY=:synthetic XDG_RUNTIME_DIR=/synthetic/runtime XDG_CURRENT_DESKTOP=Hyprland \
  DBUS_SESSION_BUS_ADDRESS=synthetic-bus HYPRLAND_INSTANCE_SIGNATURE=synthetic-instance \
  UNRELATED_SECRET=synthetic-secret T1BRIDGE_DESKTOP_PROVIDER=/synthetic/custom
mapfile -t actual <"$calls"
(( ${#actual[@]} == 4 ))
[[ ${actual[0]} == '--user cat t1-touchbar.service' ]]
[[ ${actual[1]} == '--user import-environment PATH OMARCHY_PATH WAYLAND_DISPLAY DISPLAY XDG_RUNTIME_DIR XDG_CURRENT_DESKTOP DBUS_SESSION_BUS_ADDRESS HYPRLAND_INSTANCE_SIGNATURE' ]]
[[ ${actual[2]} == '--user daemon-reload' ]]
[[ ${actual[3]} == '--user try-restart t1-touchbar.service' ]]
printf 'ok - imports only session allowlist; try-restart preserves inactive service and renderer selection\n'

: >"$calls"
if run OMARCHY_PATH=/synthetic/omarchy WAYLAND_DISPLAY=wayland-synthetic IMPORT_FAIL=yes; then
  echo 'not ok - failed import must stop before restart' >&2
  exit 1
fi
(( $(wc -l <"$calls") == 2 ))
printf 'ok - failed environment handoff stops before restart\n'
