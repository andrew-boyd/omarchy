#!/bin/bash

set -euo pipefail
(( $# == 1 )) || { echo "Usage: $0 <built-package>" >&2; exit 1; }
package=$(realpath -- "$1")
[[ -f $package && $package == *.pkg.tar.zst ]]
test_root=$(mktemp -d)
trap 'rm -rf -- "$test_root"' EXIT
mkdir -p "$test_root/root/var/lib/pacman" "$test_root/root/var/cache/pacman/pkg" "$test_root/hooks"
printf '[options]\nLocalFileSigLevel = Optional\n' >"$test_root/pacman.conf"

# No real root, scriptlets, hooks, dependencies or host package database.
fakeroot -- bash -s -- "$test_root" "$package" <<'TEST'
set -euo pipefail
test_root=$1
package=$2
root="$test_root/root"
pm=(pacman --root "$root" --dbpath "$root/var/lib/pacman"
  --cachedir "$root/var/cache/pacman/pkg" --logfile "$test_root/pacman.log"
  --config "$test_root/pacman.conf" --hookdir "$test_root/hooks" --noconfirm --noscriptlet --nodeps --nodeps)
sentinels=(etc/pam.d/sudo etc/pam.d/polkit-1 etc/pam.d/omarchy-lock-fingerprint
  usr/bin/omarchy-shell usr/lib/systemd/user/t1-touchbar.service.d/20-omarchy-desktop-provider.conf
  home/synthetic/.config/t1bridge/renderer var/lib/t1bridge/machine-data/calibration.fscl)
for path in "${sentinels[@]}"; do
  install -Dm600 /dev/null "$root/$path"
  printf 'synthetic pre-existing content: %s\n' "$path" >"$root/$path"
done
before=$(cd "$root" && sha256sum "${sentinels[@]}")
[[ $(bsdtar -xOf "$package" .PKGINFO | sed -n 's/^pkgname = //p') == t1bridge-omarchy ]]
if bsdtar -tf "$package" | grep -Fxq .INSTALL; then
  echo 'not ok - package must not contain install scriptlets' >&2
  exit 1
fi
"${pm[@]}" -U "$package"
pacman --root "$root" --dbpath "$root/var/lib/pacman" --config "$test_root/pacman.conf" -Q t1bridge-omarchy
[[ -x $root/usr/lib/t1bridge-omarchy/desktop-provider ]]
[[ -f $root/usr/lib/systemd/user/t1-touchbar.service.d/40-t1bridge-omarchy.conf ]]
"${pm[@]}" -U "$package"
[[ $before == "$(cd "$root" && sha256sum "${sentinels[@]}")" ]]
"${pm[@]}" -R t1bridge-omarchy
[[ ! -e $root/usr/lib/t1bridge-omarchy/desktop-provider ]]
[[ ! -e $root/usr/lib/systemd/user/t1-touchbar.service.d/40-t1bridge-omarchy.conf ]]
[[ $before == "$(cd "$root" && sha256sum "${sentinels[@]}")" ]]
printf 'ok - isolated pacman install/reinstall/remove leaves all existing files unchanged\n'
TEST
